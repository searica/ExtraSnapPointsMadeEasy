## Version 1.0.3
- Speed up inital load time slightly.
- Add prefabs from MoreVanillaBuildPrefabs that will be ignored.

## Version 1.0.2
- Add snap points to new build piece.

## Version 1.0.1
- Update for patch 0.217.22

## Version 1.0.0
Feature complete release. 
- Added snap points to all build pieces with the option to enable/disable snap points on a piece by piece basis.
- Added Manual (Closest) snapping mode.

## Version 0.0.2
Updated readme and added links to source code.

## Version 0.0.1
Initial release
